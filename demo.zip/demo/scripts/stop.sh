#!/bin/bash
pkill -f 'java.*-jar.*demo.*'
