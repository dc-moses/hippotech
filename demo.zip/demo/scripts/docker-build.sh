#!/bin/bash
docker build -t demo:latest .